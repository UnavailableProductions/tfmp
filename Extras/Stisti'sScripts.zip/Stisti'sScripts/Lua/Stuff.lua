

local screenrotate = 0
local screenoffset = 0
MF_loadsound("error72")
MF_loadsound("whatisevenhappening")
table.insert(mod_hook_functions["effect_always"],
	function()
		if hasfeature("blob","is","blue",1) then
			generaldata.values[SHAKE] = 2.5
		end
		if (generaldata.strings[CURRLEVEL] == "25level") then
			MF_levelrotation((math.sin(((screenrotate*0.5)/11))*3)+screenoffset*0.5)
			screenrotate = screenrotate + 2
			if (screenrotate % math.random(1,90) == 0) then
				screenoffset =  screenoffset + math.random(-50,50)
			end
		end
		if hasfeature("blob","is","purple",1) then
			
			timedmessage("$2,2ERROR")
			if (math.random(0,1) == 1) then
				local musictemp = music_random()
				generaldata2.strings[MUSIC] = musictemp
				generaldata2.strings[OLDMUSIC] = musictemp
			end
			if (math.random(0,2) == 1) then
				MF_backcolour_dim(math.random(0,6), math.random(0,4))
			end
			if (math.random(0,4) == 1) then
				generaldata.values[SHAKE] = 3
			end
			if (math.random(0,7) == 1) then
				generaldata.values[SHAKE] = 4
			end
			if (math.random(0,1) == 1) then
				MF_levelrotation((math.sin(math.random(0,60)*0.1)))
			end
			if (math.random(0,4) == 1) then
				MF_levelrotation((math.cos(math.random(0,60)*0.1)))
			end
			if (math.random(0,100) == 1) then
				MF_playsound("error72")
			end
		end	
		if hasfeature("blob","is","orange",1) then
			if (math.random(0,12) == 1) then
				MF_playsound("error72")
			end
			if (math.random(0,12) == 1) then
				MF_playsound("whatisevenhappening")
			end
		end
		if (generaldata.strings[CURRLEVEL] == "28level") then
			if hasfeature("chess","is","advanced",1) then
				timedmessage("pawn's move?")
			end
			if hasfeature("key","is","advanced",1) then
				timedmessage("key is a key... ye")
			end
			if hasfeature("bee","is","advanced",1) then
				timedmessage("NOT THE Bs")
			end
			if hasfeature("cheese","is","advanced",1) then
				timedmessage("something about travel and planets")
			end
			if hasfeature("boba","is","advanced",1) then
				timedmessage("why is the boba hot")
			end
			if hasfeature("frog","is","advanced",1) then
				timedmessage("this frog is actually a door")
			end
			if hasfeature("burger","is","advanced",1) then
				timedmessage("regrub anyone?")
			end
			if hasfeature("femboy","is","advanced",1) then
				timedmessage("pokealltoads.jpg")
			end
			if hasfeature("icely","is","advanced",1) then
				timedmessage("cba")
			end
			if hasfeature("bog","is","advanced",1) then
				timedmessage("swampy")
				MF_backcolour(5, 0)
			end
			if hasfeature("me","is","advanced",1) then
				timedmessage("is this even a meme........ OH")
			end
			if hasfeature("crab","is","advanced",1) then
				timedmessage("crab dan- oh there are no crabs")
			end
			if hasfeature("cog","is","advanced",1) then
				timedmessage("cogs spin right?")
			end
			if hasfeature("game","is","advanced",1) then
				timedmessage("you lost                                      what does that even mean")
			end
			if hasfeature("ass","is","advanced",1) then
				timedmessage("souvey no!")
			end
			if hasfeature("cba","is","advanced",1) then
				HACK_INFINITY = 200
				destroylevel("infinity")
			end
			if hasfeature("boss","is","advanced",1) then
				timedmessage("like that tutorial thing?")
			end
			if hasfeature("eye","is","advanced",1) then
				timedmessage("eye c u")
			end
		end
	end
)
MF_loadsound("oopsallbroken")

table.insert(mod_hook_functions["turn_end"],
	function()
		if hasfeature("blob","is","red",1) then
			error("Data/movement.lua:3689: bad argument #1 to 'new' (number expected, got nil)\nCheck crash.txt for more info.",999)
		end	
		if hasfeature("blob","is","yellow",1) then
			error("Data/load.lua:345: bad argument #1 to 'new' (String expected, got nil)\nCheck crash.txt for more info.",1)
		end	
		if hasfeature("blob","is","power4",1) then
			MF_playsound("oopsallbroken")
			--error("Data/load.lua:345: bad argument #1 to 'new' (IT WORKED, got nil)\nCheck crash.txt for more info.",1)
		end	
	end
)

function music_random()
	local temp = math.random(1,11)
	if (temp == 1) then
		return "baba"
	elseif (temp == 2) then
		return "crystal"	
	elseif (temp == 3) then
		return "factory"
	elseif (temp == 4) then
		return "stars"
	elseif (temp == 5) then
		return "garden"
	elseif (temp == 6) then
		return "rain"
	elseif (temp == 7) then
		return "float"
	elseif (temp == 8) then
		return "space"
	elseif (temp == 9) then
		return "ruin"
	elseif (temp == 10) then
		return "empty"
	else
		return "editorsong"
	end
end

MF_setfile("level","the code.txt")
MF_store("level","CODE","it's here... you found it...\n levelcode...\n\n 2NVZ-6QZW\n","")

local currslot = generaldata2.values[SAVESLOT] -- For that know yourself puzzle, lovely
local slotname_unf = string.lower(MF_read("settings","slotnames",tostring(currslot)))
slotname = string.gsub(slotname_unf, "%s+", "")
slotname = string.gsub(slotname, "!", "")
slotname = string.gsub(slotname, "@", "")
slotname = string.gsub(slotname, "#", "")
slotname = string.gsub(slotname, "$", "")
--slotname = string.gsub(slotname, "%", "")
slotname = string.gsub(slotname, "^", "")
slotname = string.gsub(slotname, "&", "")
slotname = string.gsub(slotname, "*", "")
--slotname = string.gsub(slotname, "(", "")
--slotname = string.gsub(slotname, ")", "")
slotname = string.gsub(slotname, "?", "")
--timedmessage(slotname .. " begin!")
MF_setfile("level","Data/Worlds/PROJECT_ITERATE/27level.ld")
MF_store("level","tiles","object001_name","text_" .. slotname)
MF_store("level","tiles","object003_name",slotname)
MF_store("level","currobjlist","26name","text_" .. slotname)
MF_store("level","currobjlist","27name",slotname)
--timedmessage(slotname .. " complete!")

particletypes =
{
	bubbles =
	{
		amount = 30,
		animation = 0,
		colour = {1, 0},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				unit.values[YVEL] = math.random(-3,-1)
				
				unit.scaleX = unit.values[YVEL] * -0.33
				unit.scaleY = unit.values[YVEL] * -0.33
			end,
	},
	soot =
	{
		amount = 30,
		animation = 1,
		colour = {0, 1},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				unit.values[YVEL] = math.random(-3,-1)
				
				unit.scaleX = unit.values[YVEL] * -0.33
				unit.scaleY = unit.values[YVEL] * -0.33
			end,
	},
	sparks =
	{
		amount = 40,
		animation = 1,
		colour = {2, 3},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				unit.values[YVEL] = math.random(-3,-1)
				
				unit.scaleX = unit.values[YVEL] * -0.23
				unit.scaleY = unit.values[YVEL] * -0.23
				
				local coloury = math.random(2,4)
				
				MF_setcolour(unitid,2,coloury)
				unit.strings[COLOUR] = tostring(2) .. "," .. tostring(coloury)
			end,
	},
	dust =
	{
		amount = 50,
		animation = 1,
		colour = {1, 0},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				unit.values[YVEL] = math.random(-3,-1)
				
				unit.scaleX = unit.values[YVEL] * -0.33 * 1.1
				unit.scaleY = unit.values[YVEL] * -0.33 * 1.1
			end,
	},
	snow =
	{
		amount = 30,
		animation = 1,
		colour = {0, 3},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				unit.values[XVEL] = math.random(-50,-10) * 0.1
				unit.values[YVEL] = math.abs(unit.values[XVEL]) * (math.random(5,15) * 0.1)
				
				unit.scaleX = math.abs(unit.values[XVEL]) * 0.2
				unit.scaleY = math.abs(unit.values[XVEL]) * 0.2
				unit.flags[INFRONT] = true
			end,
	},
	clouds =
	{
		amount = 90,
		animation = {2, 12},
		colour = {4, 3},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				unit.scaleX = 1 + math.random(-30,30) * 0.01
				unit.scaleY = unit.scaleX * 0.9
				
				unit.values[YVEL] = 0 - unit.scaleX
				unit.values[XVEL] = 0 - unit.scaleX
			end,
	},
	smoke =
	{
		amount = 30,
		animation = 3,
		colour = {1, 0},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				unit.angle = math.random(0,359)
				
				unit.scaleX = 1 + math.random(-30,30) * 0.01
				unit.scaleY = unit.scaleX
				
				unit.values[YVEL] = -1
				unit.values[DIR] = math.random(-25,25) * 0.05
			end,
	},
	pollen =
	{
		amount = 20,
		animation = 5,
		colour = {1, 0},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				unit.values[XVEL] = math.random(-20,20) * 0.1
				unit.values[YVEL] = math.random(40,80) * 0.05
				
				local size = math.random(2,5)
				unit.scaleX = size * 0.2
				unit.scaleY = size * 0.2
			end,
	},
	stars =
	{
		amount = 40,
		animation = {6, 7},
		colour = {3, 2},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				unit.values[XVEL] = ((unit.direction - 6) + math.random(0,5) * 0.1) + 0.05
				--unit.values[YVEL] = math.random(40,80) * 0.05
				
				if (unit.direction == 7) then
					MF_setcolour(unitid,1,3)
					
					unit.strings[COLOUR] = tostring(1) .. "," .. tostring(3)
				end
				
				local size = math.random(2,5)
				unit.scaleX = size * 0.2
				unit.scaleY = size * 0.2
			end,
	},
	glitter =
	{
		amount = 60,
		animation = 8,
		colour = {3, 1},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				if (math.random(1,4) == 1) then
					MF_setcolour(unitid,4,2)
					
					unit.strings[COLOUR] = tostring(4) .. "," .. tostring(1)
				end
				
				if (math.random(1,4) == 1) then
					MF_setcolour(unitid,0,3)
					
					unit.strings[COLOUR] = tostring(0) .. "," .. tostring(3)
				end
				
				local size = math.random(2,5)
				unit.scaleX = size * 0.2
				unit.scaleY = size * 0.2
			end,
	},
	leaves =
	{
		amount = 30,
		animation = {9, 10},
		colour = {6, 0},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				if (math.random(1,4) == 1) then
					MF_setcolour(unitid,6,3)
					
					unit.strings[COLOUR] = tostring(6) .. "," .. tostring(3)
				end
				
				local size = math.random(3,6)
				unit.scaleX = size * 0.2
				unit.scaleY = size * 0.2
				
				unit.values[XVEL] = math.random(-30,-10) * 0.1
				unit.values[YVEL] = math.random(0,10) * 0.05
			end,
	},
	rain =
	{
		amount = 50,
		animation = 11,
		colour = {3, 2},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				local size = math.random(3,5)
				unit.scaleX = size * 0.2
				unit.scaleY = size * 0.2
				
				unit.values[YVEL] = 80 + math.random(0,10) * 0.1
			end,
	},
	world =
	{
		amount = 40,
		animation = 13,
		colour = {4, 0},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				local scale = 0.2 + math.random(0,400) * 0.01
				
				unit.scaleX = scale
				unit.scaleY = scale
				
				unit.values[DIR] = ((math.random(0,1) * 2) - 1) * (2 - scale * 0.5)
			end,
	},
	hailstorm =
	{
		amount = 80,
		animation = 1,
		colour = {0, 3},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				
				unit.values[XVEL] = math.random(-100,-50) * 1.5
				unit.values[YVEL] = math.abs(unit.values[XVEL]*2) * (math.random(5,15) * 0.03)
				
				local temp =  math.random(10,50)
				
				
				unit.flags[INFRONT] = true
				local grlevel = math.random(0,1)
				if (grlevel == 0) then
					unit.flags[INFRONT] = true
					unit.scaleX = temp * 0.05
					unit.scaleY = temp * 0.05
					unit.values[XVEL] = math.random(-100,-50) * 1.5
					unit.values[YVEL] = math.abs(unit.values[XVEL]*2) * (math.random(5,15) * 0.03)
				else
					unit.flags[INFRONT] = false
					unit.scaleX = temp * 0.02
					unit.scaleY = temp * 0.02
					unit.values[XVEL] = (math.random(-100,-50) * 1.5)*0.5
					unit.values[YVEL] = (math.abs(unit.values[XVEL]*2) * (math.random(5,15) * 0.03))*0.5
					MF_setcolour(unitid,0,1)
					unit.strings[COLOUR] = tostring(0) .. "," .. tostring(3)
				end
			end,
	},
	layer_5 =
	{
		amount = 95,
		animation = {2, 12, 9, 10, 1, 11},
		colour = {0, 0},
		extra = 
			function(unitid)
				local unit = mmf.newObject(unitid)
				local temp =  math.random(10,50)
				
				unit.scaleX = 1 + math.random(-30,30) * 0.01
				unit.scaleY = unit.scaleX * 0.9

				unit.values[YVEL] = 0 - unit.scaleX
				unit.values[XVEL] = 0 - unit.scaleX
				if (math.random(0,4) == 2) then
					temp =  math.random(1,90)
				end
				if (math.random(0,9) == 2) then
					unit.scaleX = temp * 0.05
					unit.scaleY = temp * 0.05
					unit.values[XVEL] = math.random(-70,-30) * 0.5
					unit.values[YVEL] = math.abs(unit.values[XVEL]) * (math.random(5,15) * 0.03)
				end
				if (math.random(0,3) == 2) then
					MF_setcolour(unitid,2,0)
					unit.strings[COLOUR] = tostring(2) .. "," .. tostring(0)
				end
				if (math.random(0,12) == 2) then
					unit.scaleX = unit.scaleX * 30
				end
				if (math.random(0,7) == 2) then
					local colorx = math.random(0,6)
					MF_setcolour(unitid,colorx,3)
					unit.strings[COLOUR] = tostring(colorx) .. "," .. tostring(3)
				end
				if (math.random(0,14) == 2) then
					unit.values[XVEL] = 0.1
				end
				if (math.random(0,10) == 4) then
					unit.flags[INFRONT] = true
				end
				if (math.random(0,5) == 4) then
					unit.angle = math.random(0,359)
				end
			end,
	},
}