CBASTYLE = 4

-- CBASTYLE = 0 - Characters Become Anything
--      After erroring, the level icons will become the first slot of whatever you have set as
--      your map icons. I suggest setting it to the error sprite.

-- CBASTYLE = 1 - Constant Bothersome Annoyance
--      The game will throw constant errors and the player will have to close the game,
--      reopen it, and revert their edits of the level back to stop it from erroring.

-- CBASTYLE = 2 - Change Back the Alphabet 
--      After erroring, the level icons will change back to the order of ABC. (This will,
--      however, not move the levels back, just change the letters.)

-- CBASTYLE = 3 - Discretely Change Back Arrangement
--      Does the same thing as CBASTYLE 2 except it will not throw an error beforehand.

-- CBASTYLE = 4 - Destroy Completely Because       ...               A
--      After erroring, the entire level will destroy itself. The player will have to
--      go back into the editor and revert their changes.

mod_hook_functions["effect_always"]["cba_detector"] = function()
    for a,unit in ipairs(units) do
        if (unit.values[VISUALSTYLE] == 1) and (unit.values[VISUALLEVEL] == 1) then
            local x = unit.values[XPOS]
            local y = unit.values[YPOS]
            local cbafound = false
            local cbaunits = {unit.fixed}

            local all_left = findallhere(x-1,y)
            local all_right = findallhere(x+1,y)
            local leftfound = false

            for k,unitid in ipairs(all_left) do
                local unit2 = mmf.newObject(unitid)
                if (unit2.values[VISUALSTYLE] == 1) and (unit2.values[VISUALLEVEL] == 2) then
                    leftfound = true
                    cbaunits.c = unitid
                    break
                end
            end

            if (leftfound) then
                for k,unitid in ipairs(all_right) do
                    local unit2 = mmf.newObject(unitid)
                    if (unit2.values[VISUALSTYLE] == 1) and (unit2.values[VISUALLEVEL] == 0) then
                        cbafound = true
                        cbaunits.a = unitid
                        break
                    end
                end
            end

            if (cbafound) then
                cbaerror(cbaunits)
            else
                cbaunits = {unit.fixed}

                local all_up = findallhere(x,y-1)
                local all_down = findallhere(x,y+1)
                local upfound = false

                for k,unitid in ipairs(all_up) do
                    local unit2 = mmf.newObject(unitid)
                    if (unit2.values[VISUALSTYLE] == 1) and (unit2.values[VISUALLEVEL] == 2) then
                        upfound = true
                        cbaunits.c = unitid
                    end
                end

                if (upfound) then
                    for k,unitid in ipairs(all_down) do
                        local unit2 = mmf.newObject(unitid)
                        if (unit2.values[VISUALSTYLE] == 1) and (unit2.values[VISUALLEVEL] == 0) then
                            cbaunits.a = unitid
                            cbaerror(cbaunits)
                            break
                        end
                    end
                end
            end
        end
    end
end

function cbaerror(cbaunits)
    if (CBASTYLE == 0) then
        for a,b in pairs(cbaunits) do
            local unit = mmf.newObject(b)
            unit.values[VISUALSTYLE] = -1
            unit.values[VISUALLEVEL] = 0
        end
    elseif (CBASTYLE == 2) or (CBASTYLE == 3) then
        local cunit = mmf.newObject(cbaunits.c)
        local aunit = mmf.newObject(cbaunits.a)

        cunit.values[VISUALLEVEL] = 0
        aunit.values[VISUALLEVEL] = 2
    elseif (CBASTYLE == 4) then
        destroylevel_check = true
        destroylevel_do()
    end

    if (CBASTYLE ~= 3) then
        error("\n\n----Fatal Error: Detected Chess Battle Advanced-----\n",0)
    end
end