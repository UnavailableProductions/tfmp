CHARGE_ERR_HAPPENING = false

MF_loadsound("uncharged1")
MF_loadsound("uncharged2")
MF_loadsound("uncharged3")

table.insert(nlist.full, "charge")
table.insert(nlist.short, "charge")
table.insert(nlist.objects, "charge")

table.insert(objlistdata.alltags, "charges")

table.insert(editor_objlist_order, "text_charge")

editor_objlist["text_charge"] = 
{
	name = "text_charge",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract","charges"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {2, 1},
	colour_active = {2, 2},
}

table.insert(editor_objlist_order, "text_wires")

editor_objlist["text_wires"] = 
{
	name = "text_wires",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract","text_verb","charges"},
	tiling = -1,
	type = 1,
	layer = 20,
	colour = {0, 1},
	colour_active = {0, 3},
	argtype = {2},
}

table.insert(editor_objlist_order, "text_unplug")

editor_objlist["text_unplug"] = 
{
	name = "text_unplug",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract","text_quality","charges"},
	tiling = -1,
	type = 2,
	layer = 20,
	colour = {3, 3},
	colour_active = {4, 4},
}

table.insert(editor_objlist_order, "text_charged")

editor_objlist["text_charged"] = 
{
	name = "text_charged",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract","text_condition","charges"},
	tiling = -1,
	type = 7,
	layer = 20,
	colour = {0, 1},
	colour_active = {0, 3},
	argtype = {2},
}

table.insert(editor_objlist_order, "text_refers")

editor_objlist["text_refers"] = 
{
	name = "text_refers",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract","text_condition","charges"},
	tiling = -1,
	type = 7,
	layer = 20,
	colour = {0, 1},
	colour_active = {0, 3},
	argtype = {0, 2},
}

function addcharge(name,col)
	table.insert(editor_objlist_order, "charge_"..name)

	editor_objlist["charge_"..name] = 
	{
		name = "charge_"..name,
		sprite_in_root = false,
		unittype = "charge",
		tags = {"abstract","charges"},
		tiling = -1,
		type = 0,
		layer = 20,
		colour = col,
	}
end

addcharge("unplug",{4,4})

addcharge("you",{4,1})
addcharge("you2",{4,1})
addcharge("win",{2,4})
addcharge("stop",{5,1})

addcharge("push",{6,1})
addcharge("pull",{6,2})
addcharge("swap",{3,1})
addcharge("move",{5,3})
addcharge("auto",{4,1})
addcharge("shift",{1,3})

addcharge("defeat",{2,1})
addcharge("weak",{1,2})
addcharge("sink",{1,3})
addcharge("hot",{2,3})
addcharge("melt",{1,3})
addcharge("open",{2,4})
addcharge("shut",{2,2})
addcharge("boom",{2,2})

addcharge("safe",{0,3})
addcharge("float",{1,4})
addcharge("phantom",{0,1})

addcharge("red",{2,2})
addcharge("blue",{3,3})

formatobjlist()

condlist["refers"] = function(params,checkedconds,checkedconds_,cdata)
	for i, j in pairs(params) do
		local _params = j
	 	local unitname = mmf.newObject(cdata.unitid).strings[UNITNAME]

		if (string.sub(unitname, 1, 5) == "text_") then
			if (string.sub(unitname, 6) == _params) then
				return true, checkedconds
			end
		end

		if (string.sub(unitname, 1, 7) == "charge_") then
			if (string.sub(unitname, 8) == _params) then
				return true, checkedconds
			end
		end

		if (string.sub(unitname, 1, 7) == "script_") then
			if (string.sub(unitname, 8) == _params) then
				return true, checkedconds
			end
		end

		if hasfeature(unitname,"is","word",cdata.unitid) and (unitname == _params) then
			return true, checkedconds
		end
	end
	return false, checkedconds
end

condlist["charged"] = function(params,checkedconds,checkedconds_,cdata)
	for a,b in ipairs(params) do
		local found = false
		for c,d in ipairs(units) do
			if (hasfeature(getname(d), "is", b, d.fixed)) and (not hasfeature(getname(d), "is", "unplug", d.fixed)) then
				found = true
				break
			end
		end

		local _,empties = findallfeature(nil, "is", b, false)

		if #empties > 0 then
			found = true
		end

		if not found then
			return false,checkedconds
		end
	end
	return true,checkedconds
end

function convert(stuff,mats,dolevels_)
	local layer = map[0]
	local delthese = {}
	local mat1 = stuff
	local dolevels = dolevels_ or false
	local donewid = false
	
	if (dolevels == false) then
		if (mat1 ~= "empty") then
			local targets = {}
			
			if (unitlists[mat1] ~= nil) then
				targets = unitlists[mat1]
			end
			
			if (editor2.values[CURSORSEXIST] == 1) then
				if (featureindex[mat1] ~= nil) then
					for i,v in ipairs(featureindex[mat1]) do
						local rule = v[1]
						
						if (rule[2] == "is") and (rule[3] == "select") then
							editor.values[NAMEFLAG] = 0
							break
						end
					end
				end
			end
			
			if (#targets > 0) then
				for i,mat in pairs(mats) do
					if (mat[1] == "createall") then
						donewid = true
						break
					end
				end
				
				for i,unitid in pairs(targets) do
					local unit = mmf.newObject(unitid)
					local x,y,dir,id = unit.values[XPOS],unit.values[YPOS],unit.values[DIR],unit.values[ID]
					local name = getname(unit)
					
					local reverting = false
					local mats2 = {}

					if (unit.flags[CONVERTED] == false) then
						for a,matdata in pairs(mats) do
							local mat2 = matdata[1]
							local conds = matdata[2]
							local op = matdata[3]
							
							if (op == "write") then
								mat2 = "text_" .. matdata[1]
							elseif (op == "wires") then
								mat2 = "charge_" .. matdata[1]
							end
							
							if (reverting == false) then
								local objectfound = false
								
								if (unitreference[mat2] ~= nil) and (mat2 ~= "level") and (mat2 ~= "charge") then
									local object = unitreference[mat2]
									
									if (tileslist[object]["name"] == mat2) and ((changes[object] == nil) or (changes[object]["name"] == nil)) then
										objectfound = true
									elseif (changes[object] ~= nil) then
										if (changes[object]["name"] ~= nil) and (changes[object]["name"] == mat2) then
											objectfound = true
										end
									end
								else
									objectfound = true
								end
								
								if testcond(conds,unit.fixed) and objectfound then
									local ingameid = 0
									if (a == 1) and (donewid == false) then
										ingameid = id
									elseif (a > 1) or donewid then
										ingameid = newid()
									end
									
									if (mat2 == "revert") then
										if (unit.strings[UNITNAME] ~= unit.originalname) then
											reverting = true
										end
									elseif mat2 == "charge" then
										for _,v in ipairs(get_charges_for_effects_on_unitid(unit.fixed)) do
											table.insert(mats2, {v,ingameid,id})
										end
									end
									
									if ((mat2 ~= "charge") and (mat2 ~= "revert")) or ((mat2 == "revert") and reverting) then
										table.insert(mats2, {mat2,ingameid,id})
										unit.flags[CONVERTED] = true
									end
								end
							else
								break
							end
						end
					end
					
					if (#mats2 > 0) then
						addaction(unit.fixed,{"convert",mats2})
					end
				end
			end
		elseif (mat1 == "empty") then
			local convunitmap = {}
			
			for a,unit in pairs(units) do
				local tileid = unit.values[XPOS] + unit.values[YPOS] * roomsizex
				convunitmap[tileid] = 1
			end
			
			for i=0,roomsizex-1 do
				for j=0,roomsizey-1 do
					local empty = true
					local mats2 = {}
					
					local tileid = i + j * roomsizex
					if (convunitmap[tileid] ~= nil) then
						empty = false
					end
					
					if (emptydata[tileid] ~= nil) then
						if (emptydata[tileid]["conv"] ~= nil) and emptydata[tileid]["conv"] then
							empty = false
						end
					end
					
					if (layer:get_x(i,j) ~= 255) then
						empty = false
					end
					
					if empty then
						for a,matdata in pairs(mats) do
							local mat2 = matdata[1]
							local conds = matdata[2]
							local op = matdata[3]
							
							if (op == "write") then
								mat2 = "text_" .. matdata[1]
							elseif (op == "wires") then
								mat2 = "charge_" .. matdata[1]
							end
							
							local objectfound = false
							
							if (unitreference[mat2] ~= nil) and (mat2 ~= "level") and (mat2 ~= "charge") then
								local object = unitreference[mat2]
								
								if (tileslist[object]["name"] == mat2) and ((changes[object] == nil) or (changes[object]["name"] == nil)) then
									objectfound = true
								elseif (changes[object] ~= nil) then
									if (changes[object]["name"] ~= nil) and (changes[object]["name"] == mat2) then
										objectfound = true
									end
								end
							elseif (mat2 ~= "revert") then
								objectfound = true
							end

							if (mat2 ~= "empty") and objectfound then
								if testcond(conds,2,i,j) then
									if mat2 == "charge" then
										for _,v in ipairs(get_charges_for_effects_on_unitid(2,i,j)) do
											table.insert(mats2, {v,i,j})
										end
									else
										table.insert(mats2, {mat2,i,j})
									end
								end
							end
						end
					end
					
					if (#mats2 > 0) then
						addaction(2,{"emptyconvert",mats2})
					end
				end
			end
		end
	end
	
	if (mat1 == "level") and dolevels then
		for i,v in ipairs(mats) do
			table.insert(levelconversions, v)
		end
	end
end

function destroylevel(special_)
	destroylevel_check = true
	destroylevel_style = special_ or ""
	
	if (destroylevel_style == "infinity") or (destroylevel_style == "toocomplex") then
		setsoundname("removal",2)
	elseif (destroylevel_style ~= "empty") and (destroylevel_style ~= "bonus") and (destroylevel_style ~= "charge") then
		setsoundname("removal",1)
	end
	
	MF_musicstate(1)
	generaldata2.values[NOPLAYER] = 1
end

function destroylevel_do()
	if (generaldata.values[MODE] ~= 5) and destroylevel_check then
		MF_musicstate(1)
		generaldata2.values[NOPLAYER] = 1
		
		destroylevel_check = false
		local special = destroylevel_style or ""
		destroylevel_style = ""
		
		local dellist = {}
		for i,unit in ipairs(units) do
			table.insert(dellist, unit.fixed)
		end
		
		if (#dellist > 0) then
			for i,unitid in ipairs(dellist) do
				local unit = mmf.newObject(unitid)
				local c1,c2 = getcolour(unitid)
				local pmult,sound = checkeffecthistory("destroylevel")
				
				if (special ~= "infinity") and (special ~= "empty") and (special ~= "bonus") then
					MF_particles("bling",unit.values[XPOS],unit.values[YPOS],10 * pmult,c1,c2,1,1)
				elseif (special == "bonus") then
					MF_particles("win",unit.values[XPOS],unit.values[YPOS],10 * pmult,4,1,1,1)
				end
				
				delete(unitid,nil,nil,true)
			end
		end
		
		if (special == "infinity") then
			if (HACK_INFINITY >= 200) then
				writetext(langtext("ingame_infiniteloop"),0,screenw * 0.5 - 12,screenh * 0.5 + 60,0,true,3,true,{4,1},3)
				HACK_INFINITY = 0
			
				MF_playsound("infinity")
				
				local isignid = MF_specialcreate("Special_infinity")
				local isign = mmf.newObject(isignid)
				
				isign.x = screenw * 0.5
				isign.y = screenh * 0.5 - 36
				isign.layer = 2
				MF_setcolour(isignid,4,1)
			end
		elseif (special == "toocomplex") then
			writetext(langtext("ingame_toocomplex"),0,screenw * 0.5 - 12,screenh * 0.5,0,true,3,true,{4,1},3)
			HACK_INFINITY = 0
		
			MF_playsound("infinity")
		elseif (special == "charge") then
			writetext("uncharged!",0,screenw * 0.5 - 12,screenh * 0.5,0,true,3,true,{2,2},3)

			HACK_INFINITY = 0
		
			MF_playsound("uncharged"..tostring(math.random(1,3)))
		elseif (special == "bonus") then
			MF_playsound("bonus")
		end
		
		MF_removeblockeffect(0)
		updatecode = 1
		features = {}
		featureindex = {}
		visualfeatures = {}
		notfeatures = {}
		collectgarbage()
	elseif (generaldata.values[MODE] == 5) then
		timedmessage("Destroylevel() called from editor. Report this!")
	end
end

function checkcharge()
	if CHARGE_ERR_HAPPENING then
		return
	end

	for a,b in ipairs(units) do
		if b.strings[UNITTYPE] == "charge" then
			local safe = false
			local checkfor = string.sub(b.strings[UNITNAME],8)

			for c,d in ipairs(units) do
				if (hasfeature(getname(d),"is",checkfor,d.fixed)) and (not hasfeature(getname(d),"is","unplug",d.fixed)) then
					safe = true
					break
				end
			end

			local _,empties = findallfeature(nil, "is", checkfor,false)

			if #empties > 0 then
				safe = true
			end

			if not safe then
				CHARGE_ERR_HAPPENING = true
				destroylevel("charge")
			end
		end
	end
end

table.insert(mod_hook_functions["undoed_after"],
	function()
		CHARGE_ERR_HAPPENING = false
	end
)

table.insert(mod_hook_functions["level_start"],
		function()
			CHARGE_ERR_HAPPENING = false
		end
)

table.insert(mod_hook_functions["effect_once"],
	function()
		checkcharge()
	end
)

function isadjective(word)
	if (word == "push") or (word == "select") or (word == "stop") or (word == "meta") or (word == "unmeta") or (word == "word") then
		return true
	end
	if (word == "error") or (word == "all") or (word == "createall") or (word == "text") or (word == "level") or (word == "empty") then
		return false
	end
	if string.sub(word,1,4) == "not " then
		return false
	end
	local altname = objectpalette["text_"..word]
	return (getactualdata_objlist(altname, "type") == 2)
end

function get_charges_for_effects_on_unitid(unitid, x, y)
	local result = {}
	local uname = "empty"
	if unitid ~= 2 then
		local unit = mmf.newObject(unitid)
		uname = unit.strings[UNITNAME]
		x, y = nil, nil
	end
	for _,v in ipairs(featureindex[uname]) do
		local brule = v[1]
		local conds = v[2]
		local effect = brule[3]
		if (brule[1] == uname) and (brule[2] == "is") and isadjective(effect) and (effect ~= "greedy") then
			if testcond(conds, unitid, x, y) then
				table.insert(result, "charge_"..effect)
			end
		end
	end
	return result
end