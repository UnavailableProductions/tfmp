
--[[ @Merge: testcond() was merged ]]



--[[ @Merge: condlist.near() was merged ]]



--[[ @Merge: condlist.on() was merged ]]




--[[ @Merge: condlist.nextto() was merged ]]
