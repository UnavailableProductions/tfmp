
--[[ @Merge: hasfeature() was merged ]]
