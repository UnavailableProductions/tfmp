
--[[ @Merge: getmetadata() was merged ]]
