
--[[ @Merge: code() was merged ]]



--[[ @Merge: ruleblockeffect() was merged ]]



--[[ @Merge: addoption() was merged ]]



--[[ @Merge: codecheck() was merged ]]



--[[ @Merge: grouprules() was merged ]]



--[[ @Merge: findwordunits() was merged ]]



--[[ @Merge: postrules() was merged ]]
