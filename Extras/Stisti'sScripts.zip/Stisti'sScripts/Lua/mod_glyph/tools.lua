
--[[ @Merge: delunit() was merged ]]



--[[ @Merge: getname() was merged ]]



--[[ @Merge: findtype() was merged ]]



--[[ @Merge: update() was merged ]]



--[[ @Merge: updatedir() was merged ]]



--[[ @Merge: findall() was merged ]]



--[[ @Merge: inside() was merged ]]


