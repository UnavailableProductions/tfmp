table.insert(editor_objlist_order, "text_isin")

editor_objlist["text_isin"] = 
{
	name = "text_isin",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 1,
	layer = 20,
	colour = {0, 1},
	colour_active = {0, 3},
}

formatobjlist()

--word_names.you = "p1"
--word_names.you2 = "p2"
--word_names.defeat = "poof"
word_names.isin = "is in"