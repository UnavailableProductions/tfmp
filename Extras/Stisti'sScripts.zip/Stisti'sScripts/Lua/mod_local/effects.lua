
--[[ @Merge: effects() was merged ]]
