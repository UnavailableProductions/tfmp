-- Fixes FEELING and TEXT parameters mixed with METATEXT parameters.

--[[ @Merge: testcond() was merged ]]


--[[ Fix TEXT, NOT METATEXT, and META# parameters, fix WITHOUT and POWERED, and fix level surrounds.
All modified to change getname calls and handle level surrounds, unless specified.]]

--[[ @Merge: condlist.on() was merged ]]


--[[ @Merge: condlist.near() was merged ]]


--[[ @Merge: condlist.nextto() was merged ]]


--[[ @Merge: condlist.facing() was merged ]]


--[[ @Merge: condlist.seeing() was merged ]]


--[[ @Merge: condlist.without() was merged ]]


--[[ @Merge: condlist.above() was merged ]]


--[[ @Merge: condlist.below() was merged ]]


--[[ @Merge: condlist.besideright() was merged ]]


--[[ @Merge: condlist.besideleft() was merged ]]


--[[ @Merge: condlist.powered() was merged ]]

