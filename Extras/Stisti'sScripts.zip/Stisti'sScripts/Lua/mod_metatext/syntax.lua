-- Implement FULLUNITLIST, add units to meta# unitlist (for WITHOUT), and fix sprites on auto generation.

--[[ @Merge: addunit() was merged ]]


-- Fix TEXT IS ALL

--[[ @Merge: createall() was merged ]]

