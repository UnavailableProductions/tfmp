-- Remove lines that change name to "text"

--[[ @Merge: findtype() was merged ]]


-- Fix TEXT MIMIC X.

--[[ @Merge: getmat() was merged ]]


-- Make WRITE work with text.

--[[ @Merge: getmat_text() was merged ]]


-- Prevent text from being called "text", and also handles parameters

--[[ @Merge: getname() was merged ]]


--Fixes TEXT HAS TEXT and NOT METATEXT HAS TEXT, and implements HAS META#.

--[[ @Merge: inside() was merged ]]


-- Makes sure text units and meta# are considered special nouns

--[[ @Merge: findnoun() was merged ]]


-- Removes units from "meta#" unitlist when deleted.

--[[ @Merge: delunit() was merged ]]


-- Adds option to exclude group rules made by "TEXT" or "META#" noun. It's used in conditions.lua.

--[[ @Merge: findgroup() was merged ]]

