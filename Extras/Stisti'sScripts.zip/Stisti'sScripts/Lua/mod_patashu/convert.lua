
--[[ @Merge: conversion() was merged ]]



--[[ @Merge: convert() was merged ]]



--[[ @Merge: doconvert() was merged ]]



--[[ @Merge: dolevelconversions() was merged ]]



--[[ @Merge: handleconvertedlevels() was merged ]]



--[[ @Merge: convertlevel() was merged ]]
