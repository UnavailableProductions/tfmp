
--[[ @Merge: effects() was merged ]]



--[[ @Merge: effects_decors() was merged ]]



--[[ @Merge: shorteffectblock() was merged ]]

	

--[[ @Merge: doeffect() was merged ]]



--[[ @Merge: domaprotation() was merged ]]



--[[ @Merge: levelparticles() was merged ]]



--[[ @Merge: dotransition() was merged ]]



--[[ @Merge: particles() was merged ]]



--[[ @Merge: doparticles() was merged ]]



--[[ @Merge: adddecor() was merged ]]



--[[ @Merge: unitcoloureffect() was merged ]]



--[[ @Merge: doshorteffect() was merged ]]
