
--[[ @Merge: mapcursor_enter() was merged ]]
