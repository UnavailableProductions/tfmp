
--[[ @Merge: findfeature() was merged ]]



--[[ @Merge: hasfeature() was merged ]]



--[[ @Merge: getunitswitheffect() was merged ]]


