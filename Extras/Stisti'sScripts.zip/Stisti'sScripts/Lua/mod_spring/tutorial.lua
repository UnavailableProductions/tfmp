-- Here we add two new objects to the object list

table.insert(editor_objlist_order, "barrier")
table.insert(editor_objlist_order, "text_barrier")
table.insert(editor_objlist_order, "border")
table.insert(editor_objlist_order, "text_border")
table.insert(editor_objlist_order, "beepy")
table.insert(editor_objlist_order, "text_beepy")
table.insert(editor_objlist_order, "text_everything")
table.insert(editor_objlist_order, "helichoper")
table.insert(editor_objlist_order, "text_helichoper")
table.insert(editor_objlist_order, "sand")
table.insert(editor_objlist_order, "text_sand")
table.insert(editor_objlist_order, "glue")
table.insert(editor_objlist_order, "text_glue")
table.insert(editor_objlist_order, "stisti")
table.insert(editor_objlist_order, "text_stisti")
table.insert(editor_objlist_order, "sulsul")
table.insert(editor_objlist_order, "text_sulsul")
table.insert(editor_objlist_order, "text_something")
table.insert(editor_objlist_order, "onon")
table.insert(editor_objlist_order, "text_onon")
table.insert(editor_objlist_order, "matthew")
table.insert(editor_objlist_order, "text_matthew")
table.insert(editor_objlist_order, "shifty")
table.insert(editor_objlist_order, "text_shifty")
table.insert(editor_objlist_order, "frozenbarrier")
table.insert(editor_objlist_order, "text_frozenbarrier")
table.insert(editor_objlist_order, "log")
table.insert(editor_objlist_order, "text_log")
table.insert(editor_objlist_order, "zen")
table.insert(editor_objlist_order, "text_zen")


-- This defines the exact data for them (note that since the sprites are specific to this levelpack, sprite_in_root must be false!)

editor_objlist["sand"] = 
{
	name = "sand",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = 1,
	type = 0,
	layer = 14,
	colour = {6, 1},
}

editor_objlist["text_sand"] = 
{
	name = "text_sand",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {6, 0},
	colour_active = {6, 1},
}

editor_objlist["barrier"] = 
{
	name = "barrier",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = -1,
	type = 0,
	layer = 14,
	colour = {0, 3},
}

editor_objlist["text_barrier"] = 
{
	name = "text_barrier",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {0, 1},
	colour_active = {0, 3},
}

editor_objlist["stisti"] = 
{
	name = "stisti",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = 0,
	type = 0,
	layer = 14,
	colour = {1, 3},
}

editor_objlist["text_stisti"] = 
{
	name = "text_stisti",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {1, 1},
	colour_active = {1, 3},
}

editor_objlist["sulsul"] = 
{
	name = "sulsul",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = 2,
	type = 0,
	layer = 20,
	colour = {0, 1},
}

editor_objlist["text_sulsul"] = 
{
	name = "text_sulsul",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {1, 1},
	colour_active = {0, 1},
}

editor_objlist["border"] = 
{
	name = "border",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = -1,
	type = 0,
	layer = 0,
	colour = {1, 0},
}

editor_objlist["text_border"] = 
{
	name = "text_border",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {0, 0},
	colour_active = {1, 1},
}

editor_objlist["helichoper"] = 
{
	name = "helichoper",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = 2,
	type = 0,
	layer = 20,
	colour = {2, 2},
}

editor_objlist["text_helichoper"] = 
{
	name = "text_helichoper",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {2, 1},
	colour_active = {2, 2},
}

editor_objlist["text_everything"] = 
{
	name = "text_everything",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {2, 1},
	colour_active = {0, 3},
}

editor_objlist["text_something"] = 
{
	name = "text_something",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {2, 1},
	colour_active = {0, 3},
}

editor_objlist["text_onon"] = 
{
	name = "text_onon",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {4, 0},
	colour_active = {3, 0},
}

editor_objlist["onon"] = 
{
	name = "onon",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = 2,
	type = 0,
	layer = 20,
	colour = {3, 0},
}

editor_objlist["text_glue"] = 
{
	name = "text_glue",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {2, 1},
	colour_active = {0, 3},
}

editor_objlist["glue"] = 
{
	name = "glue",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = -1,
	type = 0,
	layer = 4,
	colour = {0, 3},
}

editor_objlist["text_beepy"] = 
{
	name = "text_beepy",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {5, 0},
	colour_active = {5, 2},
}

editor_objlist["beepy"] = 
{
	name = "beepy",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = 0,
	type = 0,
	layer = 20,
	colour = {0, 3},
}

editor_objlist["matthew"] = 
{
	name = "matthew",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = -1,
	type = 0,
	layer = 14,
	colour = {0, 3},
}

editor_objlist["text_matthew"] = 
{
	name = "text_matthew",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {0, 1},
	colour_active = {0, 3},
}

editor_objlist["text_shifty"] = 
{
	name = "text_shifty",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {2, 2},
	colour_active = {3, 4},
}

editor_objlist["shifty"] = 
{
	name = "shifty",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = 2,
	type = 0,
	layer = 20,
	colour = {3, 4},
}

editor_objlist["frozenbarrier"] = 
{
	name = "frozenbarrier",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = -1,
	type = 0,
	layer = 14,
	colour = {0, 3},
}

editor_objlist["text_frozenbarrier"] = 
{
	name = "text_frozenbarrier",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {0, 1},
	colour_active = {0, 3},
}

editor_objlist["log"] = 
{
	name = "log",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = -1,
	type = 0,
	layer = 14,
	colour = {6, 1},
}

editor_objlist["text_log"] = 
{
	name = "text_log",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {6, 3},
	colour_active = {6, 1},
}

editor_objlist["zen"] = 
{
	name = "zen",
	sprite_in_root = false,
	unittype = "object",
	tags = {"abstract"},
	tiling = 2,
	type = 0,
	layer = 20,
	colour = {1,2},
}

editor_objlist["text_zen"] = 
{
	name = "text_zen",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","abstract"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {1,1},
	colour_active = {1,2},
}