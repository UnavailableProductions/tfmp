-- OVERRIDE: allow ECHO units to echo letters (?)

--[[ @Merge: formlettermap() was merged ]]
