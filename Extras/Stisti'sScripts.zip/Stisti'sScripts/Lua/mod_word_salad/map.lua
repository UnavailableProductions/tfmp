-- OVERRIDE: let ALIVE objects read signs (this is extremely important)

--[[ @Merge: displaysigntext() was merged ]]


-- OVERRIDE: also get ENTER units when playing the unlock effect

--[[ @Merge: unlockeffect() was merged ]]


-- OVERRIDE: hide ENTER objects along with SELECT objects when unlocking something in the map

--[[ @Merge: mapunlock() was merged ]]


-- OVERRIDE: let ENTER objects see the gate indicator

--[[ @Merge: gateindicatorcheck() was merged ]]
