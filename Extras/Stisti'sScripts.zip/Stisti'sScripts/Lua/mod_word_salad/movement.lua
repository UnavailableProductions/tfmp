-- OVERRIDE: implement VESSEL, add karma for WEAK bumping into obstacle, implement HOP

--[[ @Merge: movecommand() was merged ]]



-- OVERRIDE: add karma for destructions by collision (OPEN/SHUT, EAT) while accounting for REPENT

--[[ @Merge: move() was merged ]]



-- OVERRIDE: implement HOP for pushables

--[[ @Merge: trypush() was merged ]]


-- OVERRIDE: add karma for when a WEAK object is pushed into an obstacle unless the obstacle is REPENT, implement HOP for pushables

--[[ @Merge: dopush() was merged ]]

