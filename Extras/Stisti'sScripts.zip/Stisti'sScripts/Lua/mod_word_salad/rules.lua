-- OVERRIDE: for now just try the findechounits test

--[[ @Merge: code() was merged ]]



-- OVERRIDE: handle ECHO objects

--[[ @Merge: codecheck() was merged ]]
