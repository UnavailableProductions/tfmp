-- OVERRIDE: added check for VESSEL2

--[[ @Merge: command() was merged ]]



-- OVERRIDE: keep karma after undoing

--[[ @Merge: setunitmap() was merged ]]



-- OVERRIDE: keep karma when undoing (?)

--[[ @Merge: createall() was merged ]]
