-- Functions overridden: newundo, undo
-- - Keep track of echo units, properly update code when something ECHO is undone
-- - Added "levelkarma" and "unitkarma" events

-- OVERRIDE: keep track of echo units

--[[ @Merge: newundo() was merged ]]



--[[ @Merge: undo() was merged ]]
