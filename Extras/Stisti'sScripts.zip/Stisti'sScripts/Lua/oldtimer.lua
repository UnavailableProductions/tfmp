local tlimit = 150 -- Total time (in seconds)
local timedlvl = "c10level" -- level id of level to have timer
local kicklvl = "c1level" -- level id of level to send player to when time is up
local doundowarn = true -- if the player should get an error when they undo CURRENTLY NOT WORKING
local undowarning = "Your mistakes are expensive" -- what the error should say when the player undoes CURRENTLY NOT WORKING
local doresetwarn = true -- if the player should get an error when they restart CURRENTLY NOT WORKING
local resetwarning = "Time stops for no one" -- what the error should say when the player restarts CURRENTLY NOT WORKING

local undone = false
local restarted = false
local minute = math.floor(tlimit / 60)
local second = tlimit - minute * 60
local tframe = 0
local minstring = "02"
local secstring = "30"
local timestring = "02:30"

table.insert(mod_hook_functions["effect_always"],
    function()
        local level = generaldata.strings[CURRLEVEL]
		if level == timedlvl then
		if editor.values[E_INEDITOR] == 0 then
		if minute < 10 then
			minstring = "0" .. minute
		else
			minstring = minute
		end
		if second < 10 then
			secstring = "0" .. second
		else
			secstring = second
		end
		if minute == 0 and second == 0 then
			timestring = "OH NO"
		else
			timestring = minstring .. ":" .. secstring
		end
		tframe = tframe + 1
		if tframe > 59 then
			if second ~= 0 then
				second = second - 1
			else
				if minute ~= 0 then
					minute = minute - 1
					second = 59
				else 
					sublevel(kicklvl,0,0)
					generaldata.values[TRANSITIONREASON] = 9
					generaldata.values[IGNORE] = 1
					generaldata3.values[STOPTRANSITION] = 1
					generaldata2.values[UNLOCK] = 0
					generaldata2.values[UNLOCKTIMER] = 0
					MF_loop("transition",1)
				end
			end
			tframe = 0
		end
		else
			minute = math.floor(tlimit / 60)
			second = tlimit - minute * 60
		end
		MF_letterclear("Timer")
		writetext("$2,2" .. timestring .. "$0,3", -1, (screenw * 0.5) - (#timestring * 3), screenh * 0.1, "Timer")
		else
		MF_letterclear("Timer")
		minute = math.floor(tlimit / 60)
		second = tlimit - minute * 60
		end
	end
)

table.insert(mod_hook_functions["undoed_after"],
    function()
		if level == timedlvl and doundowarn and not undone then
		error(undowarning, 0)
		undone = true
        end
	end
)

table.insert(mod_hook_functions["level_restart"],
    function()
		if level == timedlvl and doresetwarn and not restarted then
		error(resetwarning, 0)
		restarted = true
        end
	end
)

table.insert(mod_hook_functions["level_end"],
    function()
        MF_letterclear("Timer")
		minute = math.floor(tlimit / 60)
		second = tlimit - minute * 60
	end
)
