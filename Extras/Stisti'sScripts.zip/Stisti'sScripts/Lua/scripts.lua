table.insert(editor_objlist_order,"text_script")
editor_objlist["text_script"] = {
    name = "text_script",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text_noun","text_special"},
    tiling = -1,
    type = 0,
    layer = 20,
    colour = {5, 2},
    colour_active = {5, 3},
}

table.insert(editor_objlist_order,"text_code")
editor_objlist["text_code"] = {
    name = "text_code",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text_verb","text_special"},
    tiling = -1,
    type = 1,
    argtype = {0,2},
    layer = 20,
    colour = {5, 2},
    colour_active = {5, 3},
}

table.insert(editor_objlist_order,"text_unpatch")
editor_objlist["text_unpatch"] = {
    name = "text_unpatch",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text_quality","text_special"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {5, 2},
    colour_active = {5, 3},
}

table.insert(editor_objlist_order,"text_void")
editor_objlist["text_void"] = {
    name = "text_void",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text_quality","text_special"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {5, 2},
    colour_active = {5, 3},
}

table.insert(editor_objlist_order,"text_scripted")
editor_objlist["text_scripted"] = {
    name = "text_scripted",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text_conditions","text_special"},
    tiling = -1,
    type = 3,
    argtype = {0,2},
    layer = 20,
    colour = {5, 2},
    colour_active = {5, 3},
}

table.insert(nlist.full,"script")
table.insert(nlist.short,"script")
table.insert(nlist.objects,"script")

formatobjlist()

function add_script(effect)
    local scriptname = "script_"..effect
    local textname = "text_"..effect
    local textobj = editor_objlist[editor_objlist_reference[textname]]
    if textobj == nil then
        return
        --error("Bro there's no text object for this script!")
    end
    local scriptobj = {
        name = scriptname,
        sprite_in_root = false,
        unittype = "object",
        tags = {"abstract"},
        tiling = -1,
        layer = 20,
        colour = textobj.colour_active,
    }
    if textobj.type ~= 2 and textobj.type ~= 0 then
        return
    else
        if not MF_findsprite(scriptname.."_0_1.png",false) then
            if textobj.type == 0 then
                scriptobj.sprite = "script_object"
            else
                return
            end
            --error("Bro there's no sprite for this script!")
        end
    end
    print(scriptname)
    table.insert(editor_objlist_order,scriptname)
    editor_objlist[scriptname] = scriptobj
end

for _,v in pairs(editor_objlist_order) do
    if string.sub(v,1,5) == "text_" then
        add_script(string.sub(v,6))
    end
end

formatobjlist()

function patch_unit(unitid, prop)
    local unit = mmf.newObject(unitid)
    if hasfeature(getname(unit),"is","unpatch",unitid) then
        return
    end
    addundo({"patch",unit.values[ID],prop})
    updateundo = true
    if unit.patches == nil then unit.patches = {} end
    if unit.patches[prop] == nil then unit.patches[prop] = 0 end
    unit.patches[prop] = unit.patches[prop] + 1
    updatecode = 1
end

function get_patches(unitid)
    local result = {}
    local unit = mmf.newObject(unitid)
    if unit.patches == nil then return result end
    for k,v in pairs(unit.patches) do
        for i=1,v do
            table.insert(result,k)
        end
    end
    return result
end

function clear_patches(unit) --for unpatch
    if unit.patches == nil then return end
    local patches_copy = {}
    for k,v in pairs(unit.patches) do
        patches_copy[k] = v
    end
    addundo({"unpatch",unit.values[ID],patches_copy})
    updateundo = true
    updatecode = 1
    unit.patches = nil
    local x,y = unit.values[XPOS],unit.values[YPOS]
    local pmult,sound = checkeffecthistory("unlock")
    MF_particles("unlock",x,y,15 * pmult,2,4,1,1)
end

function add_patch_rules()
    local patch_added = false
    local needed_rules = {}
    for _,v in pairs(units) do
        if v.patches ~= nil then
            local unitname = v.strings[UNITNAME]
            for k,conut in pairs(v.patches) do
                if needed_rules[unitname] == nil then
                    needed_rules[unitname] = {}
                end
                if needed_rules[unitname][k] == nil then
                    needed_rules[unitname][k] = 0
                end
                needed_rules[unitname][k] = math.max(needed_rules[unitname][k],conut)
            end
        end
    end
    for unitname,rules in pairs(needed_rules) do
        for rule,count in pairs(rules) do
            for i=1,count do
                local condtable = {}
                for j = 1,i do
                    table.insert(condtable,rule)
                end
                addoption({unitname,"is",rule},{{"scripted",condtable}},{},false)
            end
            patch_added = true
        end
    end
    return patch_added
end

function update_patch_rules()
    local doned = {}

    if (unitlists["script"] ~= nil) then
        for _,id in ipairs(unitlists["script"]) do
            local unit = mmf.newObject(id)
            local name = getname(unit)
            local effect = string.sub(name,8)
            if string.sub(name,1,7) == "script_" then
                local x,y = unit.values[XPOS],unit.values[YPOS]
                local tileid = x + y * roomsizex
                local isdone = false

                if (unitmap[tileid] ~= nil) then
                    local things = findallhere(x,y)

                    if (#things > 0) then
                        for a,b in ipairs(things) do
                            if floating(b,unit.fixed,x,y) then
                                if (b ~= unit.fixed) and not (string.sub(mmf.newObject(b).strings[UNITNAME],1,7) == "script_") then
                                    patch_unit(b, effect)
                                    isdone = true
                                end
                            end
                        end
                    end
                end

                if isdone and (unit.flags[DEAD] == false) then
                    table.insert(doned, unit)
                end
            end
        end

        if (#doned> 0) then
            setsoundname("turn",10)
        end

        for i,unit in ipairs(doned) do
            updateundo = true

            local ufloat = unit.values[FLOAT]
            local ded = unit.flags[DEAD]

            unit.values[FLOAT] = 2
            unit.values[EFFECTCOUNT] = math.random(-10,10)
            unit.values[POSITIONING] = 7
            unit.flags[DEAD] = true

            local x,y = unit.values[XPOS],unit.values[YPOS]

            if (spritedata.values[VISION] == 1) and (unit.values[ID] == spritedata.values[CAMTARGET]) then
                updatevisiontargets()
            end

            if (ufloat ~= 2) and (ded == false) then
                addundo({"done",unit.strings[UNITNAME],unit.values[XPOS],unit.values[YPOS],unit.values[DIR],unit.values[ID],unit.fixed,ufloat,nil,unit.patches})
            end

            delunit(unit.fixed)
            dynamicat(x,y)
        end

    end

    local unpatch = getunitswitheffect("unpatch")
    for _,unit in ipairs(unpatch) do
        clear_patches(unit)
    end

end

condlist["scripted"] = function(params,checkedconds,checkedconds_,cdata)
    local unitid,x,y = cdata.unitid,cdata.x,cdata.y
    local unit = mmf.newObject(unitid)

    if unit == nil then return false end

    if #params == 0 then
        if unit.patches == nil then return false end
        for _,__ in pairs(unit.patches) do
            return true, checkedconds
        end
        return false, checkedconds
    end

    local count_table = {} --count of each effect in params
    for _,v in ipairs(params) do
        if count_table[v] == nil then
            count_table[v] = 0
        end
        count_table[v] = count_table[v] + 1
    end

    local patches = unit.patches
    if patches == nil then return false end
    --comp patches w/ count_table
    for k,v in pairs(count_table) do
        if (patches[k] == nil) or (patches[k] < v) then
            return false
        end
    end
    return not (hasfeature(unit.strings[UNITNAME],"is","void",unitid)),checkedconds
end

function undo()
    local result = 0
    HACK_INFINITY = 0
    logevents = false

    if (#undobuffer > 1) then
        result = 1
        local currentundo = undobuffer[2]

        -- MF_alert("Undoing: " .. tostring(#undobuffer))

        do_mod_hook("undoed")

        last_key = currentundo.key or 0
        Fixedseed = currentundo.fixedseed or 100

        if (currentundo ~= nil) then
            for i,line in ipairs(currentundo) do
                local style = line[1]

                if (style == "update") then
                    local uid = line[9]

                    if (paradox[uid] == nil) then
                        local unitid = getunitid(line[9])

                        local unit = mmf.newObject(unitid)

                        local oldx,oldy = unit.values[XPOS],unit.values[YPOS]
                        local x,y,dir = line[3],line[4],line[5]
                        unit.values[XPOS] = x
                        unit.values[YPOS] = y
                        unit.values[DIR] = dir
                        unit.values[POSITIONING] = 0

                        updateunitmap(unitid,oldx,oldy,x,y,unit.strings[UNITNAME])
                        dynamic(unitid)
                        dynamicat(oldx,oldy)

                        if (spritedata.values[CAMTARGET] == uid) then
                            MF_updatevision(dir)
                        end

                        local ox = math.abs(oldx-x)
                        local oy = math.abs(oldy-y)

                        if (ox + oy == 1) and (unit.values[TILING] == 2) then
                            unit.values[VISUALDIR] = ((unit.values[VISUALDIR] - 1)+4) % 4
                            unit.direction = unit.values[DIR] * 8 + unit.values[VISUALDIR]
                        end

                        if (unit.strings[UNITTYPE] == "text") then
                            updatecode = 1
                        end

                        local undowordunits = currentundo.wordunits
                        local undowordrelatedunits = currentundo.wordrelatedunits

                        if (#undowordunits > 0) then
                            for a,b in pairs(undowordunits) do
                                if (b == line[9]) then
                                    updatecode = 1
                                end
                            end
                        end

                        if (#undowordrelatedunits > 0) then
                            for a,b in pairs(undowordrelatedunits) do
                                if (b == line[9]) then
                                    updatecode = 1
                                end
                            end
                        end
                    else
                        particles("hot",line[3],line[4],1,{1, 1})
                    end
                elseif (style == "remove") then
                    local uid = line[6]
                    local baseuid = line[7] or -1

                    if (paradox[uid] == nil) and (paradox[baseuid] == nil) then
                        local x,y,dir,levelfile,levelname,vislevel,complete,visstyle,maplevel,colour,clearcolour,followed,back_init,ogname,signtext,patches = line[3],line[4],line[5],line[8],line[9],line[10],line[11],line[12],line[13],line[14],line[15],line[16],line[17],line[18],line[19],line[20]
                        local name = line[2]

                        local unitname = ""
                        local unitid = 0

                        --MF_alert("Trying to create " .. name .. ", " .. tostring(unitreference[name]))
                        unitname = unitreference[name]
                        if (name == "level") and (unitreference[name] ~= "level") then
                            unitname = "level"
                            unitreference["level"] = "level"
                            MF_alert("ALERT! Unitreference for level was wrong!")
                        end

                        unitid = MF_emptycreate(unitname,x,y)

                        local unit = mmf.newObject(unitid)
                        unit.values[ONLINE] = 1
                        unit.values[XPOS] = x
                        unit.values[YPOS] = y
                        unit.values[DIR] = dir
                        unit.values[ID] = line[6]
                        unit.flags[9] = true

                        unit.strings[U_LEVELFILE] = levelfile
                        unit.strings[U_LEVELNAME] = levelname
                        unit.flags[MAPLEVEL] = maplevel
                        unit.values[VISUALLEVEL] = vislevel
                        unit.values[VISUALSTYLE] = visstyle
                        unit.values[COMPLETED] = complete

                        unit.strings[COLOUR] = colour
                        unit.strings[CLEARCOLOUR] = clearcolour
                        unit.strings[UNITSIGNTEXT] = signtext or ""

                        if (unit.className == "level") then
                            MF_setcolourfromstring(unitid,colour)
                        end

                        addunit(unitid,true)
                        addunitmap(unitid,x,y,unit.strings[UNITNAME])
                        dynamic(unitid)

                        unit.followed = followed
                        unit.back_init = back_init
                        unit.originalname = ogname
                        unit.patches = patches

                        if (unit.strings[UNITTYPE] == "text") then
                            updatecode = 1
                        end

                        if (spritedata.values[VISION] == 1) then
                            unit.x = -24
                            unit.y = -24
                        end

                        local undowordunits = currentundo.wordunits
                        local undowordrelatedunits = currentundo.wordrelatedunits

                        if (#undowordunits > 0) then
                            for a,b in ipairs(undowordunits) do
                                if (b == line[6]) then
                                    updatecode = 1
                                end
                            end
                        end

                        if (#undowordrelatedunits > 0) then
                            for a,b in ipairs(undowordrelatedunits) do
                                if (b == line[6]) then
                                    updatecode = 1
                                end
                            end
                        end
                    else
                        particles("hot",line[3],line[4],1,{1, 1})
                    end
                elseif (style == "create") then
                    local uid = line[3]
                    local baseid = line[4]
                    local source = line[5]

                    if (paradox[uid] == nil) then
                        local unitid = getunitid(line[3])

                        local unit = mmf.newObject(unitid)
                        local unitname = unit.strings[UNITNAME]
                        local x,y = unit.values[XPOS],unit.values[YPOS]
                        local unittype = unit.strings[UNITTYPE]

                        unit = {}
                        delunit(unitid)
                        MF_remove(unitid)
                        dynamicat(x,y)

                        if (unittype == "text") then
                            updatecode = 1
                        end

                        local undowordunits = currentundo.wordunits
                        local undowordrelatedunits = currentundo.wordrelatedunits

                        if (#undowordunits > 0) then
                            for a,b in ipairs(undowordunits) do
                                if (b == line[3]) then
                                    updatecode = 1
                                end
                            end
                        end

                        if (#undowordrelatedunits > 0) then
                            for a,b in ipairs(undowordrelatedunits) do
                                if (b == line[3]) then
                                    updatecode = 1
                                end
                            end
                        end
                    end
                elseif (style == "backset") then
                    local uid = line[3]

                    if (paradox[uid] == nil) then
                        local unitid = getunitid(line[3])
                        local unit = mmf.newObject(unitid)

                        unit.back_init = line[4]
                    end
                elseif (style == "done") then
                    local unitid = line[7]
                    --print(unitid)
                    local unit = mmf.newObject(unitid)

                    unit.values[FLOAT] = line[8]
                    unit.angle = 0
                    unit.values[POSITIONING] = 0
                    unit.values[A] = 0
                    unit.values[VISUALLEVEL] = 0
                    unit.flags[DEAD] = false

                    --print(unit.className .. ", " .. tostring(unitid) .. ", " .. tostring(line[3]) .. ", " .. unit.strings[UNITNAME])

                    addunit(unitid,true)
                    unit.originalname = line[9]
                    unit.patches = line[10]

                    if (unit.values[TILING] == 1) then
                        dynamic(unitid)
                    end
                elseif (style == "float") then
                    local uid = line[3]

                    if (paradox[uid] == nil) then
                        local unitid = getunitid(line[3])

                        -- K�kk� ratkaisu!
                        if (unitid ~= nil) and (unitid ~= 0) then
                            local unit = mmf.newObject(unitid)
                            unit.values[FLOAT] = tonumber(line[4])
                        end
                    end
                elseif (style == "levelupdate") then
                    MF_setroomoffset(line[2],line[3])
                    mapdir = line[6]
                elseif (style == "maprotation") then
                    maprotation = line[2]
                    MF_levelrotation(maprotation)
                elseif (style == "mapdir") then
                    mapdir = line[2]
                elseif (style == "mapcursor") then
                    mapcursor_set(line[3],line[4],line[5],line[10])

                    local undowordunits = currentundo.wordunits
                    local undowordrelatedunits = currentundo.wordrelatedunits

                    local unitid = getunitid(line[10])
                    if (unitid ~= nil) and (unitid ~= 0) then
                        local unit = mmf.newObject(unitid)

                        if (unit.strings[UNITTYPE] == "text") then
                            updatecode = 1
                        end
                    end

                    if (#undowordunits > 0) then
                        for a,b in pairs(undowordunits) do
                            if (b == line[10]) then
                                updatecode = 1
                            end
                        end
                    end

                    if (#undowordrelatedunits > 0) then
                        for a,b in pairs(undowordrelatedunits) do
                            if (b == line[10]) then
                                updatecode = 1
                            end
                        end
                    end
                elseif (style == "colour") then
                    local unitid = getunitid(line[2])
                    MF_setcolour(unitid,line[3],line[4])
                    local unit = mmf.newObject(unitid)
                    unit.values[A] = line[5]
                elseif (style == "broken") then
                    local unitid = getunitid(line[3])
                    local unit = mmf.newObject(unitid)
                    --MF_alert(unit.strings[UNITNAME])
                    unit.broken = 1 - line[2]
                elseif (style == "bonus") then
                    local style = 1 - line[2]
                    MF_bonus(style)
                elseif (style == "followed") then
                    local unitid = getunitid(line[2])
                    local unit = mmf.newObject(unitid)

                    unit.followed = line[3]
                elseif (style == "startvision") then
                    local target = line[2]

                    if (line[2] ~= 0) and (line[2] ~= 0.5) then
                        target = getunitid(line[2])
                    end

                    visionmode(0,target,true)
                elseif (style == "stopvision") then
                    local target = line[2]

                    if (line[2] ~= 0) and (line[2] ~= 0.5) then
                        target = getunitid(line[2])
                    end

                    visionmode(1,target,true,{line[3],line[4],line[5]})
                elseif (style == "visiontarget") then
                    local unitid = getunitid(line[2])

                    if (spritedata.values[VISION] == 1) and (unitid ~= 0) then
                        local unit = mmf.newObject(unitid)
                        MF_updatevision(unit.values[DIR])
                        MF_updatevisionpos(unit.values[XPOS],unit.values[YPOS])
                        spritedata.values[CAMTARGET] = line[2]
                    end
                elseif (style == "holder") then
                    local unitid = getunitid(line[2])
                    local unit = mmf.newObject(unitid)

                    unit.holder = line[3]
                elseif (style == "unpatch") then
                    local unitid = MF_getfixed(line[2])
                    local unit = mmf.newObject(unitid)
                    local patches = line[3]
                    unit.patches = patches
                    updatecode = 1
                elseif (style == "patch") then
                    local unitid = MF_getfixed(line[2])
                    local unit = mmf.newObject(unitid)
                    local prop = line[3]
                    if (unit.patches ~= nil) then
                        unit.patches[prop] = unit.patches[prop] - 1
                        if unit.patches[prop] <= 0 then
                            unit.patches[prop] = nil
                        end
                    end
                    updatecode = 1
                end
            end
        end

        local nextundo = undobuffer[1]
        nextundo.wordunits = {}
        nextundo.wordrelatedunits = {}
        nextundo.visiontargets = {}
        nextundo.fixedseed = Fixedseed

        for i,v in ipairs(currentundo.wordunits) do
            table.insert(nextundo.wordunits, v)
        end
        for i,v in ipairs(currentundo.wordrelatedunits) do
            table.insert(nextundo.wordrelatedunits, v)
        end

        if (#currentundo.visiontargets > 0) then
            visiontargets = {}
            for i,v in ipairs(currentundo.visiontargets) do
                table.insert(nextundo.visiontargets, v)

                local fix = MF_getfixed(v)
                if (fix ~= nil) then
                    table.insert(visiontargets, fix)
                end
            end
        end

        table.remove(undobuffer, 2)
    end

    --MF_alert("Current fixed seed: " .. tostring(Fixedseed))

    do_mod_hook("undoed_after")
    logevents = true

    return result
end

function delete(unitid,x_,y_,total_,noinside_)
    local total = total_ or false
    local noinside = noinside_ or false

    local check = unitid

    if (unitid == 2) then
        check = 200 + x_ + y_ * roomsizex
    end

    if (deleted[check] == nil) then
        local unit = {}
        local x,y,dir = 0,0,4
        local unitname = ""
        local insidename = ""

        if (unitid ~= 2) then
            unit = mmf.newObject(unitid)
            x,y,dir = unit.values[XPOS],unit.values[YPOS],unit.values[DIR]
            unitname = unit.strings[UNITNAME]
            insidename = getname(unit)
        else
            x,y = x_,y_
            unitname = "empty"
            insidename = "empty"
        end

        x = math.floor(x)
        y = math.floor(y)

        if (total == false) and inbounds(x,y,1) and (noinside == false) then
            local leveldata = {}

            if (unitid == 2) then
                dir = emptydir(x,y)
            else
                leveldata = {unit.strings[U_LEVELFILE],unit.strings[U_LEVELNAME],unit.flags[MAPLEVEL],unit.values[VISUALLEVEL],unit.values[VISUALSTYLE],unit.values[COMPLETED],unit.strings[COLOUR],unit.strings[CLEARCOLOUR]}
            end

            inside(insidename,x,y,dir,unitid,leveldata)
        end

        if (unitid ~= 2) then
            if (spritedata.values[CAMTARGET] == unit.values[ID]) then
                changevisiontarget(unit.fixed)
            end

            addundo({"remove",unitname,x,y,dir,unit.values[ID],unit.values[ID],unit.strings[U_LEVELFILE],unit.strings[U_LEVELNAME],unit.values[VISUALLEVEL],unit.values[COMPLETED],unit.values[VISUALSTYLE],unit.flags[MAPLEVEL],unit.strings[COLOUR],unit.strings[CLEARCOLOUR],unit.followed,unit.back_init,unit.originalname,unit.strings[UNITSIGNTEXT],unit.patches},unitid)
            unit = {}
            delunit(unitid)
            MF_remove(unitid)

            --MF_alert("Removed " .. tostring(unitid))

            if inbounds(x,y,1) then
                dynamicat(x,y)
            end
        end

        deleted[check] = 1
    else
        MF_alert("already deleted")
    end
end

function setunitmap()
    unitmap = {}
    unittypeshere = {}
    local delthese = {}

    local limit = 6

    if (generaldata.strings[WORLD] == generaldata.strings[BASEWORLD]) and ((generaldata.strings[CURRLEVEL] == "89level") or (generaldata.strings[CURRLEVEL] == "33level")) then
        limit = 3
    end

    if (generaldata.strings[WORLD] == "baba_m") and ((generaldata.strings[CURRLEVEL] == "89level") or (generaldata.strings[CURRLEVEL] == "33level")) then
        limit = 2
    end

    for i,unit in ipairs(units) do
        local tileid = unit.values[XPOS] + unit.values[YPOS] * roomsizex
        local valid = true

        --print(tostring(unit.values[XPOS]) .. ", " .. tostring(unit.values[YPOS]) .. ", " .. unit.strings[UNITNAME])

        if (unitmap[tileid] == nil) then
            unitmap[tileid] = {}
            unittypeshere[tileid] = {}
        end

        local uth = unittypeshere[tileid]
        local name = unit.strings[UNITNAME]

        if (uth[name] == nil) then
            uth[name] = 0
        end

        if (uth[name] < limit) then
            uth[name] = uth[name] + 1
        elseif (string.len(unit.strings[U_LEVELFILE]) == 0) then
            table.insert(delthese, unit)
            valid = false
        end

        if valid then
            table.insert(unitmap[tileid], unit.fixed)
        end
    end

    for i,unit in ipairs(delthese) do
        local x,y,dir,unitname = unit.values[XPOS],unit.values[YPOS],unit.values[DIR],unit.strings[UNITNAME]
        addundo({"remove",unitname,x,y,dir,unit.values[ID],unit.values[ID],unit.strings[U_LEVELFILE],unit.strings[U_LEVELNAME],unit.values[VISUALLEVEL],unit.values[COMPLETED],unit.values[VISUALSTYLE],unit.flags[MAPLEVEL],unit.strings[COLOUR],unit.strings[CLEARCOLOUR],unit.followed,unit.back_init,unit.originalname,unit.strings[UNITSIGNTEXT],unit.patches})
        delunit(unit.fixed)
        MF_remove(unit.fixed)
    end
end

function doconvert(data,extrarule_)
    local style = data[2]
    local mats2 = data[3]

    local unitid = data[1]
    local unit = {}
    local x,y,dir,name,id,completed,float,ogname = 0,0,0,"",0,0,0,""
    local delthis = false
    local delthis_createall = false
    local delthis_createall_ = false

    if (unitid ~= 2) then
        unit = mmf.newObject(unitid)
        x,y,dir,name,id,completed,ogname = unit.values[XPOS],unit.values[YPOS],unit.values[DIR],unit.strings[UNITNAME],unit.values[ID],unit.values[COMPLETED],unit.originalname
    end

    local cdata = {}
    cdata[1] = name

    if (style == "convert") then
        for a,mats2data in ipairs(mats2) do
            local mat2 = mats2data[1]
            local ingameid = mats2data[2]
            local baseingameid = mats2data[3]

            local unitname = ""

            if (mat2 == "revert") and (unitid ~= 2) and (ogname ~= nil) then
                local originalname = ogname

                if (string.len(originalname) > 0) then
                    unitname = unitreference[originalname]
                    mat2 = originalname
                else
                    unitname = nil
                end

                if (source == "emptyconvert") then
                    unitname = ""
                    mat2 = "empty"
                end

                if (unitname == unit.className) then
                    MF_alert("Trying to revert object to the same thing: " .. tostring(originalname))
                    return
                end
            elseif (mat2 == "revert") and (unitid == 2) then
                MF_alert("Trying to revert empty")
                return
            end

            if (mat2 ~= "empty") and (mat2 ~= "error") and (mat2 ~= "revert") and (mat2 ~= "createall") then
                if (mats2data[1] ~= "revert") then
                    unitname = unitreference[mat2]
                end

                if (mat2 == "level") then
                    unitname = "level"
                end

                if (unitname == nil) then
                    MF_alert("no className found for " .. mat2 .. "!")
                    return
                end

                local newunitid = MF_emptycreate(unitname,x,y)
                local newunit = mmf.newObject(newunitid)

                newunit.values[ONLINE] = 1
                newunit.values[XPOS] = x
                newunit.values[YPOS] = y
                newunit.values[DIR] = dir
                newunit.values[POSITIONING] = 20

                newunit.values[VISUALLEVEL] = unit.values[VISUALLEVEL]
                newunit.values[VISUALSTYLE] = unit.values[VISUALSTYLE]
                newunit.values[COMPLETED] = completed

                newunit.strings[COLOUR] = unit.strings[COLOUR]
                newunit.strings[CLEARCOLOUR] = unit.strings[CLEARCOLOUR]

                if (unitname == "level") then
                    newunit.values[COMPLETED] = math.max(completed, 1)
                    newunit.flags[LEVEL_JUSTCONVERTED] = true

                    if (string.len(unit.strings[LEVELFILE]) > 0) then
                        newunit.values[COMPLETED] = math.max(completed, 2)
                    end

                    if (string.len(unit.strings[COLOUR]) == 0) or (string.len(unit.strings[CLEARCOLOUR]) == 0) then
                        newunit.strings[COLOUR] = "1,2"
                        newunit.strings[CLEARCOLOUR] = "1,3"
                        MF_setcolour(newunitid,1,2)
                    else
                        local c = MF_parsestring(unit.strings[COLOUR])
                        MF_setcolour(newunitid,c[1],c[2])
                    end

                    newunit.visible = true
                end

                newunit.values[ID] = ingameid

                newunit.strings[U_LEVELFILE] = unit.strings[U_LEVELFILE]
                newunit.strings[U_LEVELNAME] = unit.strings[U_LEVELNAME]
                newunit.flags[MAPLEVEL] = unit.flags[MAPLEVEL]

                newunit.values[EFFECT] = 1
                newunit.flags[9] = true
                newunit.flags[CONVERTED] = true

                cdata[2] = mat2

                addundo({"convert",cdata[1],cdata[2],ingameid,baseingameid,x,y,dir})
                addundo({"create",mat2,ingameid,baseingameid,"convert",x,y,dir})

                addunit(newunitid)
                addunitmap(newunitid,x,y,newunit.strings[UNITNAME])
                poscorrect(newunitid,generaldata2.values[ROOMROTATION],generaldata2.values[ZOOM],0)

                if (spritedata.values[VISION] == 0) or ((newunit.values[TILING] == 1) and (newunit.values[ZLAYER] <= 10) and (newunit.values[ZLAYER] >= 0)) then
                    dynamic(newunitid)
                end

                newunit.new = false
                newunit.originalname = unit.originalname

                if (newunit.strings[UNITTYPE] == "text") then
                    updatecode = 1
                else
                    local newname = newunit.strings[UNITNAME]
                    local notnewname = "not " .. newunit.strings[UNITNAME]

                    if (featureindex["word"] ~= nil) then
                        for i,v in ipairs(featureindex["word"]) do
                            local rule = v[1]
                            local conds = v[2]

                            if (rule[2] == "is") and (rule[3] == "word") then
                                if (rule[1] == newname) then
                                    updatecode = 1
                                    break
                                elseif (unitid ~= 2) then
                                    if (rule[1] == unitname) then
                                        updatecode = 1
                                        break
                                    end
                                end

                                if (#conds > 0) then
                                    for a,b in ipairs(conds) do
                                        if (b[2] ~= nil) and (#b[2] > 0) then
                                            for c,d in ipairs(b[2]) do
                                                if (d == newname) or ((string.sub(d, 1, 4) == "not ") and (string.sub(d, 5) ~= newname)) then
                                                    updatecode = 1
                                                    break
                                                elseif (unitid ~= 2) then
                                                    if (d == unitname) or ((string.sub(d, 1, 4) == "not ") and (string.sub(d, 5) ~= unitname)) then
                                                        updatecode = 1
                                                        break
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end

                delthis = true
            elseif (mat2 == "error") then
                if (unitid ~= 2) then
                    local unit = mmf.newObject(unitid)
                    local x,y = unit.values[XPOS],unit.values[YPOS]
                    local pmult,sound = checkeffecthistory("paradox")
                    local c1,c2 = getcolour(unitid)
                    MF_particles("unlock",x,y,20 * pmult,c1,c2,1,1)
                    --paradox[id] = 1
                end

                delthis = true
            elseif (mat2 == "empty") then
                addundo({"convert",cdata[1],"empty",ingameid,baseingameid,x,y,dir})
                updateunitmap(unitid,x,y,x,y,unit.strings[UNITNAME])
                delthis = true

                local tileid = x + y * roomsizex
                if (emptydata[tileid] == nil) then
                    emptydata[tileid] = {}
                end

                emptydata[tileid]["conv"] = true
            elseif (mat2 == "createall") then
                delthis_createall = createall_single(unitid)
                delthis = delthis_createall
                delthis_createall_ = true
            end
        end

        if delthis_createall_ and (delthis_createall == false) and delthis then
            delthis = false
        end

        if delthis and (unit.flags[DEAD] == false) then
            addundo({"remove",unit.strings[UNITNAME],unit.values[XPOS],unit.values[YPOS],unit.values[DIR],unit.values[ID],unit.values[ID],unit.strings[U_LEVELFILE],unit.strings[U_LEVELNAME],unit.values[VISUALLEVEL],unit.values[COMPLETED],unit.values[VISUALSTYLE],unit.flags[MAPLEVEL],unit.strings[COLOUR],unit.strings[CLEARCOLOUR],unit.followed,unit.back_init,unit.originalname,unit.strings[UNITSIGNTEXT],unit.patches})

            if (unit.strings[UNITTYPE] == "text") then
                updatecode = 1
            end

            delunit(unitid)
            dynamic(unitid)
            MF_specialremove(unitid,2)
        end
    elseif (style == "emptyconvert") then
        for a,mats2data in ipairs(mats2) do
            local mat2 = mats2data[1]
            local i = mats2data[2]
            local j = mats2data[3]

            if (mat2 ~= "createall") and (mat2 ~= "error") then
                local unitname = unitreference[mat2]
                local newunitid = MF_emptycreate(unitname,i,j)
                local newunit = mmf.newObject(newunitid)

                cdata[1] = "empty"

                local id = newid()
                local dir = emptydir(i,j)

                if (dir == 4) then
                    dir = fixedrandom(0,3)
                end

                newunit.values[ONLINE] = 1
                newunit.values[XPOS] = i
                newunit.values[YPOS] = j
                newunit.values[DIR] = dir
                newunit.values[ID] = id
                newunit.values[EFFECT] = 1
                newunit.flags[9] = true
                newunit.flags[CONVERTED] = true

                cdata[2] = mat2
                addundo({"convert",cdata[1],cdata[2],id,id,i,j,dir})
                addundo({"create",mat2,id,-1,"emptyconvert",i,j,dir})

                addunit(newunitid)
                addunitmap(newunitid,i,j,newunit.strings[UNITNAME])
                dynamic(newunitid)

                newunit.originalname = "empty"

                local tileid = i + j * roomsizex
                if (emptydata[tileid] == nil) then
                    emptydata[tileid] = {}
                end

                emptydata[tileid]["conv"] = true

                if (newunit.strings[UNITTYPE] == "text") then
                    updatecode = 1
                else
                    if (featureindex["word"] ~= nil) then
                        for i,v in ipairs(featureindex["word"]) do
                            local rule = v[1]
                            if (rule[1] == newunit.strings[UNITNAME]) then
                                updatecode = 1
                            elseif (unitid ~= 2) then
                                if (rule[1] == unit.strings[UNITNAME]) then
                                    updatecode = 1
                                end
                            end
                        end
                    end
                end
            elseif (mat2 == "createall") then
                createall_single(2,nil,i,j)
            end
        end
    end
end
