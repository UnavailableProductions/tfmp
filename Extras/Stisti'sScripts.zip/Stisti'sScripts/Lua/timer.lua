local timedlvls = {"271level","390level","389level","391level","395level","424level","401level","425level","500level","428level","1155level","467level","1156level","548level","552level","522level","626level","613level","627level","629level"} -- add level ids here to let the game know that these levels are timed
local normallvls = {} -- DO NOT ADD ANYTHING TO THIS. non-timed levels will automatically be added here with a value of "true". timed levels will have a value of "false".
timedlvls["271level"] = 150 -- put the level id of the new level in the [] like this
timedlvls["390level"] = 45
timedlvls["395level"] = 80
timedlvls["424level"] = 10
timedlvls["428level"] = 15
timedlvls["389level"] = -1
timedlvls["1155level"] = -1
timedlvls["401level"] = -1
timedlvls["391level"] = -1 -- each time you add a timed level, you need to add a line like this setting its time limit (in seconds)
timedlvls["425level"] = 230
timedlvls["500level"] = 86400
timedlvls["467level"] = 150
timedlvls["548level"] = 60
timedlvls["552level"] = 75
timedlvls["626level"] = 10
timedlvls["627level"] = 15
timedlvls["613level"] = -1
timedlvls["522level"] = -1
timedlvls["1156level"] = 240
timedlvls["1155level"] = -1
timedlvls["629level"] = 50

local world = generaldata.strings[WORLD]
local path = "Data/Worlds/" .. world .. "/"
local levels_ = MF_filelist(path,"*.l")
-- local tlvl = {}
local timestring = "00:00"
local tempstring = "00:"
local minute = 0
local second = 0
local lastlevel = ""
local tlimit = -1
local tframe = 0
local taunts = {"TOO SLOW", "NUH UH", "WHOOPS!", "TRY AGAIN", "NEXT TIME?", "OOF", "THAT SUCKS", "OH NO", "WELP", "WOW", "GREAT JOB", "INCREDIBLE", "AMAZING WORK", "THE SUN RISES GREEN", "YOU KNOW WHAT THAT MEANS!"}
-- a random taunt is chosen to be shown when the player runs out of time, add your own by putting it in this table as a string (add it multiple times to increase its chance of appearing)
local taunt = "" -- this is automatically set to the randomly chosen taunt, do not change it as it will do absolutely nothing (hopefully)

--[[ 

NOTES:

unlike the previous version of the code, the level the player is kicked out to upon running out of time is unchangeable.
the player will always be sent to the previous level, so you should always make timed levels entered from non-timed levels to avoid exploits.

if you want to change the ticking sound, i'll leave "SOUND HERE" comments showing where all references to the sound are.
change the sound name to the desired sound's filename (without the .ogg extension), or if you don't want to change the actual code, replace Sounds/Timer.ogg with your sound. it is case-sensitive!

the Time's Up sound can be changed in the same way. its name is TimeUp.ogg

i think that's all, so happy panicking! <3

--]]

for i=1,#levels_ do
	if timedlvls[i .. "level"] == nil then
		normallvls[i .. "level"] = true
	else
		normallvls[i .. "level"] = false
	end
end

table.insert(mod_hook_functions["level_start"],
    function()
		lastlevel = generaldata2.strings[PREVIOUSLEVEL]
		MF_loadsound("Timer") -- SOUND HERE
		MF_loadsound("TimeUp")
		MF_loadsound("Fish")
		taunt = taunts[math.floor(math.random(0, #taunts))]
        local level = generaldata.strings[CURRLEVEL]
		for i=1,#timedlvls do
			if level == timedlvls[i] then
				-- tlvl = timedlvls[i]
				tlimit = timedlvls[level]
				if tlimit == nil then
					tlimit = -1
				end
				-- local klvl = lastlevel
				minute = math.floor(tlimit / 60)
				second = tlimit - minute * 60
				if minute <= 9 then
					tempstring = "0" .. minute .. ":" -- 09:
				else
					tempstring = minute .. ":" -- 10:
				end
				if second <= 9 then
					timestring = tempstring .. "0" .. second -- 09:09
				else
					timestring = tempstring .. second -- 10:10
				end
			else
				MF_letterclear("Timer")
			end
		end
		timedmessage(level .. "'s timelimit is " .. tlimit)
	end
)

table.insert(mod_hook_functions["effect_always"],
    function()
        if tlimit ~= -1 and tlimit ~= nil and not normallvls[level] and generaldata.values[MODE] ~= 5 then
			if minute <= 9 then
				tempstring = "0" .. minute .. ":"
			else
				tempstring = minute .. ":"
			end
			if second <= 9 then
				timestring = tempstring .. "0" .. second
			else
				timestring = tempstring .. second
			end
			if minute == 0 and second == 0 then
			timestring = taunt
			end
			tframe = tframe + 1
			if tframe > 59 then
				if second ~= 0 then
					second = second - 1
					MF_playsound("Timer") -- SOUND HERE
				else
					if minute ~= 0 then
						minute = minute - 1
						second = 59
					else
						if taunt == "YOU KNOW WHAT THAT MEANS!" then
							MF_playsound("Fish")
						else
							MF_playsound("TimeUp")
						end
						sublevel(lastlevel,0,0)
						generaldata.values[TRANSITIONREASON] = 9
						generaldata.values[IGNORE] = 1
						generaldata3.values[STOPTRANSITION] = 1
						generaldata2.values[UNLOCK] = 0
						generaldata2.values[UNLOCKTIMER] = 0
						MF_loop("transition",1)
						minute = -1
						second = -1
						tlimit = -1
					end
				end
			tframe = 0
			end
			MF_letterclear("Timer")
			writetext("$2,2" .. timestring .. "$0,3", -1, (screenw * 0.5) - (#timestring * 3), (screenh * 0.1), "Timer")
		else
			MF_letterclear("Timer")
			timestring = "00:00"
			tempstring = "00:"
			minute = -1
			second = -1
			tlimit = -1
		end
	end
)

table.insert(mod_hook_functions["level_end"],
    function()
		MF_letterclear("Timer")
		timestring = "00:00"
		tempstring = "00:"
		minute = -1
		second = -1
		tlimit = -1
	end
)